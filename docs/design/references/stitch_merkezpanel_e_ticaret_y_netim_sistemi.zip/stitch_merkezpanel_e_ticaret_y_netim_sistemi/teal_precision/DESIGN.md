---
name: Teal Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#404847'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707977'
  outline-variant: '#bfc8c6'
  surface-tint: '#316763'
  primary: '#003633'
  on-primary: '#ffffff'
  primary-container: '#134e4a'
  on-primary-container: '#87beb8'
  inverse-primary: '#9ad1cb'
  secondary: '#006a63'
  on-secondary: '#ffffff'
  secondary-container: '#99efe5'
  on-secondary-container: '#006f67'
  tertiary: '#263230'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c4846'
  on-tertiary-container: '#a9b6b4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b5ede7'
  primary-fixed-dim: '#9ad1cb'
  on-primary-fixed: '#00201e'
  on-primary-fixed-variant: '#144f4b'
  secondary-fixed: '#9cf2e8'
  secondary-fixed-dim: '#80d5cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#00504a'
  tertiary-fixed: '#d8e5e2'
  tertiary-fixed-dim: '#bcc9c6'
  on-tertiary-fixed: '#121e1c'
  on-tertiary-fixed-variant: '#3d4947'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  sidebar-width: 280px
  header-height: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system focuses on institutional reliability, precision, and clarity. It is tailored for operational environments where efficiency and high information density are paramount. The visual style leans toward **Corporate/Modern Minimalism**, characterized by systematic alignment, a disciplined color palette, and high-quality functional typography.

The emotional response should be one of competence and stability. To achieve this, the system avoids decorative elements, instead relying on strict rhythmic spacing and a clear visual hierarchy to guide the user through complex workflows.

## Colors
The color strategy is anchored by the primary shade **#134e4a**, used for core actions and navigation elements. To maintain a clean operational look, the interface utilizes a tiered surface approach:
- **Surface**: The main background layer is a cool, neutral light gray to reduce eye strain.
- **Container**: White surfaces are used for cards, tables, and sidebar content to provide clear separation of concerns.
- **States**: Success, warning, and error states should utilize standard semantic tones but maintain the saturation levels of the primary brand color to ensure visual harmony.

## Typography
This design system utilizes **Hanken Grotesk** exclusively to ensure a modern, sharp, and highly legible interface. 

- **Hierarchy**: Use `Display` for page hero sections only. `Headline` is the standard for primary page titles. 
- **Body Text**: Use `body-lg` for long-form content and `body-md` for data tables, form inputs, and general UI descriptions.
- **Labels**: Labels should be used for secondary information, metadata, and micro-copy.
- **Weights**: Reserve Bold/700 for Display and SemiBold/600 for Titles to ensure information density doesn't feel cluttered.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. The sidebar is fixed at 280px, while the main content area utilizes a fluid grid that maximizes data visibility.

- **Alignment**: Strict vertical alignment must be maintained between breadcrumbs, page headers, and the start of the content grid. 
- **Rhythm**: All spacing between components follows an 8px modular scale. 
- **Structure**: Headers are locked to the top of the viewport with a consistent 64px height. Use a 12-column grid for desktop layouts with a consistent 24px gutter.

## Elevation & Depth
Depth is conveyed through **Low-contrast outlines** rather than heavy shadows to maintain a clean, "flat" professional aesthetic.

- **Containers**: Cards and sections are defined by a 1px border (`#e2e8f0`).
- **Interaction**: Only use subtle ambient shadows (opacity 0.05) on hovered elements or modals to signify lift.
- **Layering**: Use the surface-container tiers (Neutral vs White) to create visual separation without adding unnecessary visual weight.

## Shapes
The shape language is disciplined and geometric. A standard **8px (0.5rem)** radius is applied to all primary UI components including buttons, cards, and input fields to soften the professional aesthetic without becoming overly playful. 

Small components like tags or status badges may use the same radius to maintain a consistent silhouette across the entire interface.

## Components
### Buttons
Buttons are strictly defined by three size tiers:
- **Large**: 48px height, 16px font (body-lg). Used for primary landing actions.
- **Medium**: 40px height, 14px font (body-md). The default for most UI interactions.
- **Small**: 32px height, 12px font (label). Used for dense tables and toolbar actions.
Primary buttons always use `#134e4a` with white text.

### Input Fields
Inputs follow the Medium button height (40px) with an 8px border radius. Use a 1px border. Labels must always be placed above the field using the `label` typography style.

### Cards & Surfaces
Cards use a white background, 1px border, and 8px border radius. Padding inside cards should be consistent at 24px (`stack-lg`) for desktop and 16px (`stack-md`) for mobile.

### Navigation & Breadcrumbs
Breadcrumbs use the `label` typography style and are always left-aligned with the main page title. The sidebar width of 280px is a constant across all operational screens to ensure a reliable navigation anchor.